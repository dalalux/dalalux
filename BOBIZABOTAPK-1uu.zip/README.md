<p align="center"> 
<b>༺═════════[👸]══════════༻</b>
</p>
<p align="center">
<img src="https://telegra.ph/file/c0c8a7440635f381fe098.jpg" width="300" height="300"/>
</p>
<p align="center">
  <a href="#"><img src="http://readme-typing-svg.herokuapp.com?font=Fira+Code&pause=1000&width=435&lines=BOBIZA+BOT+Whatsapp+Multidevice+Bot+;By+NOUREDDINE+OUAFY" alt="">
